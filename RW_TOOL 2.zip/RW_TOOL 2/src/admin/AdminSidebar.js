import React from "react";
import { NavLink } from "react-router-dom";
import "./admin.css";

export default function AdminSidebar() {
  const navItems = [
    {
      path: "/admin/dashboard",
      icon: "bi-house-door-fill",
      label: "Dashboard"
    },
    {
      path: "/admin/user-management",
      icon: "bi-people-fill",
      label: "User Management"
    },
    {
      path: "/admin/access-control",
      icon: "bi-shield-check",
      label: "Access Control"
    },
    {
      path: "/admin/reports-management",
      icon: "bi-file-earmark-bar-graph",
      label: "Reports Management"
    },
    {
      path: "/admin/settings",
      icon: "bi-gear-fill",
      label: "Settings"
    }
  ];

  return (
    <aside className="admin-sidebar">
      {/* Company Logo Section */}
      <div style={{ padding: '20px', borderBottom: '1px solid #e9ecef' }}>
        <div className="d-flex align-items-center gap-2">
          <div style={{
            width: '32px',
            height: '32px',
            background: 'linear-gradient(135deg, #0072CE, #00A87E)',
            borderRadius: '6px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontWeight: 'bold',
            fontSize: '14px'
          }}>
            SC
          </div>
          <div>
            <div style={{ fontWeight: '600', fontSize: '14px', color: '#212529' }}>
              Standard Chartered
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-column nav">
        {navItems.map((item, index) => (
          <NavLink
            key={index}
            to={item.path}
            className={({ isActive }) => 
              `nav-link ${isActive ? 'active' : ''}`
            }
          >
            <i className={`bi ${item.icon}`}></i>
            {item.label}
          </NavLink>
        ))}
      </nav>

      {/* Bottom User Info */}
      <div style={{
        position: 'absolute',
        bottom: '20px',
        left: '20px',
        right: '20px',
        padding: '12px',
        background: '#f8f9fa',
        borderRadius: '8px',
        fontSize: '11px',
        color: '#6c757d'
      }}>
        <div className="d-flex align-items-center gap-2">
          <div style={{
            width: '24px',
            height: '24px',
            background: '#4285f4',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontWeight: 'bold',
            fontSize: '10px'
          }}>
            A
          </div>
          <div>
            <div style={{ fontWeight: '600', color: '#212529' }}>Abc</div>
            <div>abc@sc.com</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
