import React, { useState } from "react";
import { CreateModuleModal } from "./Modals";
import "./admin.css";

export default function AccessControl() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [modules, setModules] = useState([
    {
      id: 1,
      name: "HR Management System",
      branch: "Branch A",
      icon: "people",
      iconClass: "hr",
      dataBranches: ["HR-01", "HR-02"],
      assignedUsers: ["John Smith", "Sarah Johnson"],
      lastModified: "3 weeks ago"
    },
    {
      id: 2,
      name: "Finance Portal",
      branch: "Branch B",
      icon: "currency-dollar",
      iconClass: "finance",
      dataBranches: ["FN-01", "FN-02"],
      assignedUsers: ["Mike Wilson"],
      lastModified: "2 days ago"
    },
    {
      id: 3,
      name: "Inventory System",
      branch: "Branch C",
      icon: "boxes",
      iconClass: "inventory",
      dataBranches: ["INV-01"],
      assignedUsers: ["Lisa Anderson", "Tom Brown"],
      lastModified: "1 week ago"
    }
  ]);

  const handleCreateModule = () => {
    setShowCreateModal(true);
  };

  const handleSaveModule = (moduleData) => {
    const newModule = {
      id: modules.length + 1,
      name: moduleData.moduleName,
      branch: moduleData.mainBranch,
      icon: "gear",
      iconClass: "hr",
      dataBranches: moduleData.dataBranches,
      assignedUsers: moduleData.assignedUsers,
      lastModified: "Just created"
    };
    setModules([...modules, newModule]);
  };

  const handleEditModule = (moduleId) => {
    console.log("Edit module:", moduleId);
  };

  const handleDeleteModule = (moduleId) => {
    if (window.confirm("Are you sure you want to delete this module?")) {
      setModules(modules.filter(module => module.id !== moduleId));
    }
  };

  // Filter modules based on search term
  const filteredModules = modules.filter(module =>
    module.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    module.branch.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      {/* Page Header */}
      <div className="d-flex justify-content-between align-items-center mb-2">
        <div>
          <h4 style={{ color: '#212529', fontWeight: '600', margin: 0 }}>Access Control Management</h4>
        </div>
        <button className="create-module-btn" onClick={handleCreateModule}>
          <i className="bi bi-plus"></i>
          Create Access Module
        </button>
      </div>

      <p className="access-control-subtitle">Configure access permissions for modules</p>

      {/* Filters */}
      <div className="access-control-filters mb-4">
        <div className="row">
          <div className="col-md-6">
            <div className="input-group">
              <span className="input-group-text bg-white border-end-0">
                <i className="bi bi-search text-muted"></i>
              </span>
              <input
                type="text"
                className="form-control border-start-0"
                placeholder="Search modules..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="col-md-3">
            <button className="btn btn-outline-secondary">
              <i className="bi bi-funnel me-2"></i>
              Filters
            </button>
          </div>
          <div className="col-md-3">
            <button className="btn btn-outline-secondary">
              <i className="bi bi-download me-2"></i>
              Export
            </button>
          </div>
        </div>
      </div>

      {/* Modules Count */}
      <div className="mb-4">
        <p className="mb-0" style={{ color: '#6c757d', fontSize: '14px' }}>
          Showing {filteredModules.length} of {modules.length} Modules
        </p>
      </div>

      {/* Modules Grid */}
      <div className="modules-grid">
        {filteredModules.map((module) => (
          <div key={module.id} className="module-card">
            {/* Module Header */}
            <div className="module-header">
              <div className={`module-icon ${module.iconClass}`}>
                <i className={`bi bi-${module.icon}`}></i>
              </div>
              <div className="module-info">
                <h5>{module.name}</h5>
                <small>{module.branch}</small>
              </div>
            </div>

            {/* Data/Branches */}
            <div className="module-section">
              <h6>Data/Branches:</h6>
              <div className="tag-list">
                {module.dataBranches.map((branch, index) => (
                  <span key={index} className="tag">{branch}</span>
                ))}
              </div>
            </div>

            {/* Assigned Users */}
            <div className="module-section">
              <h6>Assigned Users:</h6>
              <div className="tag-list">
                {module.assignedUsers.map((user, index) => (
                  <span key={index} className="tag user-tag">{user}</span>
                ))}
              </div>
            </div>

            {/* Last Modified */}
            <div className="module-section">
              <h6>Last Modified:</h6>
              <p className="mb-0" style={{ fontSize: '14px', color: '#6c757d' }}>
                {module.lastModified}
              </p>
            </div>

            {/* Module Actions */}
            <div className="module-actions">
              <button
                className="action-btn edit"
                onClick={() => handleEditModule(module.id)}
                title="Edit Module"
              >
                <i className="bi bi-pencil"></i>
              </button>
              <button
                className="action-btn delete"
                onClick={() => handleDeleteModule(module.id)}
                title="Delete Module"
              >
                <i className="bi bi-trash"></i>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Create Module Modal */}
      <CreateModuleModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSave={handleSaveModule}
      />
    </div>
  );
}
