import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AddUserModal, CreateModuleModal, RecentReportsModal } from "./Modals";
import "./admin.css";

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [showCreateModuleModal, setShowCreateModuleModal] = useState(false);
  const [showRecentReportsModal, setShowRecentReportsModal] = useState(false);

  // Quick Action handlers
  const handleAddNewUser = () => {
    setShowAddUserModal(true);
  };

  const handleCreateModule = () => {
    setShowCreateModuleModal(true);
  };

  const handleManageUsers = () => {
    navigate('/admin/user-management');
  };

  const handleRecentReports = () => {
    setShowRecentReportsModal(true);
  };

  const handleSaveUser = (userData) => {
    console.log('New user created:', userData);
    // In a real app, this would save to backend
  };

  const handleSaveModule = (moduleData) => {
    console.log('New module created:', moduleData);
    // In a real app, this would save to backend
  };

  // Sample data for recent activities
  const recentActivities = [
    {
      user: { name: "John Smith", initials: "JS" },
      action: "Accessed",
      module: "Branch A → A1",
      time: "2 hours ago",
      status: "completed"
    },
    {
      user: { name: "Sarah Johnson", initials: "SJ" },
      action: "Modified Access",
      module: "Branch B",
      time: "3 hours ago",
      status: "completed"
    },
    {
      user: { name: "Mike Wilson", initials: "MW" },
      action: "Created Module",
      module: "Branch C → C2",
      time: "5 hours ago",
      status: "completed"
    },
    {
      user: { name: "Emily Brown", initials: "EB" },
      action: "Updated Profile",
      module: "User Settings",
      time: "6 hours ago",
      status: "completed"
    },
    {
      user: { name: "David Lee", initials: "DL" },
      action: "Requested Access",
      module: "Branch A → A2",
      time: "8 hours ago",
      status: "pending"
    }
  ];

  const chartData = [
    { day: "Sun", approvals: 1, rejections: 0, requests: 1 },
    { day: "Mon", approvals: 2, rejections: 1, requests: 2 },
    { day: "Tue", approvals: 1, rejections: 0, requests: 1 },
    { day: "Wed", approvals: 3, rejections: 1, requests: 3 },
    { day: "Thu", approvals: 2, rejections: 0, requests: 2 },
    { day: "Fri", approvals: 1, rejections: 1, requests: 2 },
    { day: "Sat", approvals: 0, rejections: 0, requests: 1 }
  ];

  const maxValue = Math.max(...chartData.flatMap(d => [d.approvals, d.rejections, d.requests]));

  return (
    <div>
      {/* Page Title */}
      <div className="mb-4">
        <h4 className="mb-1" style={{ color: '#212529', fontWeight: '600' }}>Admin Dashboard</h4>
        <p className="mb-0" style={{ color: '#6c757d' }}>Welcome back, Mr. Abc</p>
      </div>

      {/* Statistics Cards Row */}
      <div className="row mb-4">
        <div className="col-xl-3 col-md-6 mb-3">
          <div className="dashboard-card card">
            <div className="card-body">
              <div className="card-icon users">
                <i className="bi bi-people-fill"></i>
              </div>
              <h3 className="card-number">124</h3>
              <p className="card-title">Active Users</p>
            </div>
          </div>
        </div>
        <div className="col-xl-3 col-md-6 mb-3">
          <div className="dashboard-card card">
            <div className="card-body">
              <div className="card-icon reports">
                <i className="bi bi-bar-chart-fill"></i>
              </div>
              <h3 className="card-number">7</h3>
              <p className="card-title">Total Reports</p>
            </div>
          </div>
        </div>
        <div className="col-xl-3 col-md-6 mb-3">
          <div className="dashboard-card card">
            <div className="card-body">
              <div className="card-icon pending">
                <i className="bi bi-hourglass-split"></i>
              </div>
              <h3 className="card-number">3</h3>
              <p className="card-title">Pending Approvals</p>
            </div>
          </div>
        </div>
        <div className="col-xl-3 col-md-6 mb-3">
          <div className="dashboard-card card">
            <div className="card-body">
              <div className="card-icon approved">
                <i className="bi bi-check-circle-fill"></i>
              </div>
              <h3 className="card-number">3</h3>
              <p className="card-title">Approved Reports</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions Section */}
      <div className="row mb-4">
        <div className="col-12">
          <div className="quick-actions">
            <h6>Quick Actions</h6>
            <div className="row">
              <div className="col-xl-3 col-lg-6 col-md-6 mb-2">
                <button className="quick-action-btn btn w-100" onClick={handleAddNewUser}>
                  <i className="bi bi-plus-circle" style={{ color: '#2196f3' }}></i>
                  <span>Add New User</span>
                </button>
              </div>
              <div className="col-xl-3 col-lg-6 col-md-6 mb-2">
                <button className="quick-action-btn btn w-100" onClick={handleCreateModule}>
                  <i className="bi bi-gear" style={{ color: '#4caf50' }}></i>
                  <span>Create Module</span>
                </button>
              </div>
              <div className="col-xl-3 col-lg-6 col-md-6 mb-2">
                <button className="quick-action-btn btn w-100" onClick={handleManageUsers}>
                  <i className="bi bi-people" style={{ color: '#ff9800' }}></i>
                  <span>Manage Users</span>
                </button>
              </div>
              <div className="col-xl-3 col-lg-6 col-md-6 mb-2">
                <button className="quick-action-btn btn w-100" onClick={handleRecentReports}>
                  <i className="bi bi-bar-chart" style={{ color: '#9c27b0' }}></i>
                  <span>Recent Reports</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Row */}
      <div className="row">
        {/* Recent Activities */}
        <div className="col-lg-8 mb-4">
          <div className="recent-activities">
            <div style={{ padding: '20px', borderBottom: '1px solid #e9ecef' }}>
              <h6 style={{ margin: 0, fontWeight: '600', color: '#212529' }}>Recent Activities</h6>
            </div>
            <div className="table-responsive">
              <table className="table">
                <thead>
                  <tr>
                    <th>User</th>
                    <th>Action</th>
                    <th>Module/Branch</th>
                    <th>Time</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentActivities.map((activity, index) => (
                    <tr key={index}>
                      <td>
                        <div className="d-flex align-items-center">
                          <div className="user-avatar">{activity.user.initials}</div>
                          <span>{activity.user.name}</span>
                        </div>
                      </td>
                      <td>{activity.action}</td>
                      <td>{activity.module}</td>
                      <td>{activity.time}</td>
                      <td>
                        <span className={`status-badge ${activity.status}`}>
                          {activity.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Reports Activity Overview */}
        <div className="col-lg-4 mb-4">
          <div className="reports-activity">
            <h6 style={{ margin: '0 0 20px 0', fontWeight: '600', color: '#212529' }}>
              Reports Activity Overview
            </h6>
            
            {/* Simple Bar Chart */}
            <div style={{ height: '200px', display: 'flex', alignItems: 'end', gap: '8px', justifyContent: 'center' }}>
              {chartData.map((data, index) => (
                <div key={index} style={{ textAlign: 'center', flex: 1 }}>
                  <div style={{ display: 'flex', flexDirection: 'column-reverse', alignItems: 'center', height: '160px', gap: '2px' }}>
                    {/* Approvals */}
                    <div
                      style={{
                        width: '8px',
                        height: `${(data.approvals / maxValue) * 40}px`,
                        background: '#4caf50',
                        borderRadius: '1px'
                      }}
                    ></div>
                    {/* Rejections */}
                    <div
                      style={{
                        width: '8px',
                        height: `${(data.rejections / maxValue) * 40}px`,
                        background: '#f44336',
                        borderRadius: '1px'
                      }}
                    ></div>
                    {/* Requests */}
                    <div
                      style={{
                        width: '8px',
                        height: `${(data.requests / maxValue) * 40}px`,
                        background: '#2196f3',
                        borderRadius: '1px'
                      }}
                    ></div>
                  </div>
                  <div style={{ fontSize: '11px', color: '#6c757d', marginTop: '8px' }}>
                    {data.day}
                  </div>
                </div>
              ))}
            </div>

            {/* Chart Legend */}
            <div className="chart-legend">
              <div className="legend-item">
                <div className="legend-color approvals"></div>
                <span>Approvals</span>
              </div>
              <div className="legend-item">
                <div className="legend-color rejections"></div>
                <span>Rejections</span>
              </div>
              <div className="legend-item">
                <div className="legend-color requests"></div>
                <span>Report Requests</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <AddUserModal
        isOpen={showAddUserModal}
        onClose={() => setShowAddUserModal(false)}
        onSave={handleSaveUser}
      />

      <CreateModuleModal
        isOpen={showCreateModuleModal}
        onClose={() => setShowCreateModuleModal(false)}
        onSave={handleSaveModule}
      />

      <RecentReportsModal
        isOpen={showRecentReportsModal}
        onClose={() => setShowRecentReportsModal(false)}
      />
    </div>
  );
}
