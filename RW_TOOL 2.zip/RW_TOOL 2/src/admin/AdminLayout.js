import React from "react";
import { Routes, Route } from "react-router-dom";
import AdminHeader from "./AdminHeader";
import AdminSidebar from "./AdminSidebar";
import AdminDashboard from "./AdminDashboard";
import UserManagement from "./UserManagement";
import AccessControl from "./AccessControl";
import ReportsManagement from "./ReportsManagement";
import AdminSettings from "./AdminSettings";
import Footer from "../user/Footer";
import "./admin.css";

export default function AdminLayout() {
  return (
    <div className="admin-layout">
      <AdminHeader />
      
      <div className="admin-main">
        <AdminSidebar />
        
        <div className="admin-content">
          <Routes>
            <Route path="/" element={<AdminDashboard />} />
            <Route path="/dashboard" element={<AdminDashboard />} />
            <Route path="/user-management" element={<UserManagement />} />
            <Route path="/access-control" element={<AccessControl />} />
            <Route path="/reports-management" element={<ReportsManagement />} />
            <Route path="/settings" element={<AdminSettings />} />
          </Routes>
        </div>
      </div>

      <Footer />
    </div>
  );
}
